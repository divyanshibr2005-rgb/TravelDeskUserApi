﻿using Dapper;
using MySqlConnector;
using System.Data;
using TravelDeskUserApi.IRepository;
using TravelDeskUserApi.Models;

namespace TravelDeskUserApi.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly string _connectionString;

        public UserRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        private IDbConnection CreateConnection() => new MySqlConnection(_connectionString);

        public async Task<IEnumerable<User>> GetAllUsers()
        {
            const string sql = @"SELECT uid, 
                                first_name AS FirstName, 
                                last_name AS LastName, 
                                email, 
                                role_id AS RoleId, 
                                dept,
                                password_hash AS PasswordHash,
                                manager_id AS ManagerId, 
                                is_active AS IsActive 
                         FROM users";
            using var connection = CreateConnection();
            return await connection.QueryAsync<User>(sql);
        }

        public async Task<User?> GetUserById(int id)
        {
            const string sql = @"SELECT uid, 
                                first_name AS FirstName, 
                                last_name AS LastName, 
                                email, 
                                role_id AS RoleId, 
                                dept,
                                password_hash AS PasswordHash,
                                manager_id AS ManagerId, 
                                is_active AS IsActive 
                         FROM users WHERE uid=@Id";
            using var connection = CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<User>(sql, new { Id = id });
        }

        public async Task<User?> GetUserByEmail(string email)
        {
            const string sql = @"SELECT uid, 
                                first_name AS FirstName, 
                                last_name AS LastName, 
                                email, 
                                role_id AS RoleId, 
                                dept,
                                password_hash AS PasswordHash,
                                manager_id AS ManagerId, 
                                is_active AS IsActive 
                         FROM users WHERE email = @Email LIMIT 1";
            using var connection = CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<User>(sql, new { Email = email });
        }

        public async Task<int> AddUser(User user)
        {
            const string sql = @"INSERT INTO users (first_name, last_name, email, password_hash, role_id, dept, manager_id, is_active) 
                                VALUES (@FirstName, @LastName, @Email, @PasswordHash, @RoleId, @Dept, @ManagerId, @IsActive);
                                SELECT LAST_INSERT_ID();";
            using var connection = CreateConnection();
            return await connection.ExecuteScalarAsync<int>(sql, user);
        }

        public async Task<bool> UpdateUser(User user)
        {
            const string sql = @"UPDATE users SET first_name = @FirstName, last_name = @LastName, 
                                email = @Email, role_id = @RoleId, dept = @Dept, 
                                manager_id = @ManagerId, is_active = @IsActive 
                                WHERE uid = @Uid";
            using var connection = CreateConnection();
            var rowsAffected = await connection.ExecuteAsync(sql, user);
            return rowsAffected > 0;
        }

        public async Task<bool> DeleteUser(int id)
        {
            const string sql = "DELETE FROM users WHERE uid = @Id";
            using var connection = CreateConnection();
            var rowsAffected = await connection.ExecuteAsync(sql, new { Id = id });
            return rowsAffected > 0;
        }
    }
}