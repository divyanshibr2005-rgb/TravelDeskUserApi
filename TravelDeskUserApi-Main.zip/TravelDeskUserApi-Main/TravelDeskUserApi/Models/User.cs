﻿namespace TravelDeskUserApi.Models
{
    public class User
    {
        public int Uid { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public int RoleId { get; set; }
        public string? Dept { get; set; }
        public int? ManagerId { get; set; }
        public bool IsActive { get; set; }

        // Optional: for display purposes
        public string? RoleName { get; set; }
    }
}