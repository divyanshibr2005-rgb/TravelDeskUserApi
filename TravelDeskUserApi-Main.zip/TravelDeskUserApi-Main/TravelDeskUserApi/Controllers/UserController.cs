﻿using Microsoft.AspNetCore.Mvc;
using TravelDeskUserApi.IRepository;
using TravelDeskUserApi.Models;

namespace TravelDeskAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository _userRepository;

        public UsersController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        // GET: api/users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetAllUsers()
        {
            var users = await _userRepository.GetAllUsers();
            return Ok(users);
        }

        // GET: api/users/5
        [HttpGet("{id}")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = await _userRepository.GetUserById(id);
            if (user == null)
            {
                return NotFound($"User with ID {id} not found.");
            }
            return Ok(user);
        }

        // POST: api/users
        [HttpPost]
        public async Task<ActionResult<User>> CreateUser(User user)
        {
            // Prevent duplicate email creation
            if (!string.IsNullOrWhiteSpace(user.Email))
            {
                var existing = await _userRepository.GetUserByEmail(user.Email);
                if (existing != null)
                {
                    return Conflict(new { message = "Email already in use." });
                }
            }

            var newId = await _userRepository.AddUser(user);
            user.Uid = newId;
            return CreatedAtAction(nameof(GetUser), new { id = user.Uid }, user);
        }

        // PUT: api/users/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, User user)
        {
            if (id != user.Uid)
            {
                return BadRequest("ID mismatch.");
            }

            var success = await _userRepository.UpdateUser(user);
            if (!success)
            {
                return NotFound();
            }

            return NoContent(); // 204 Success, but no content to return
        }

        // DELETE: api/users/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var success = await _userRepository.DeleteUser(id);
            if (!success)
            {
                return NotFound();
            }

            return Ok(new { message = "User deleted successfully." });
        }
    }
}