using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using TravelDeskUserApi.IRepository;
using TravelDeskUserApi.Models;
using TravelDeskUserApi.Services;

namespace TravelDeskUserApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        private readonly JwtService _jwtService;

        public AuthController(IUserRepository userRepository, JwtService jwtService)
        {
            _userRepository = userRepository;
            _jwtService = jwtService;
        }

        // POST: api/auth/register
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest request)
        {
            var existing = await _userRepository.GetUserByEmail(request.Email);
            if (existing != null)
                return Conflict(new { message = "Email already in use." });

            var user = new User
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                PasswordHash = request.Password,
                RoleId = request.RoleId,
                Dept = request.Dept,
                ManagerId = request.ManagerId,
                IsActive = true
            };

            var newId = await _userRepository.AddUser(user);
            user.Uid = newId;
            user.PasswordHash = string.Empty; // don't return the password
            return CreatedAtAction(null, new { id = newId }, user);
        }

        // POST: api/auth/login
        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest request)
        {
            var user = await _userRepository.GetUserByEmail(request.Email);
            if (user == null)
                return Unauthorized(new { message = "Invalid credentials." });

            // Plaintext comparison per request (insecure — see note below)
            if (request.Password != user.PasswordHash)
                return Unauthorized(new { message = "Invalid credentials." });

            var (token, expires) = _jwtService.GenerateToken(user);
            user.PasswordHash = string.Empty; // don't return the password

            var response = new AuthResponse
            {
                Token = token,
                ExpiresAt = expires,
                User = user
            };

            return Ok(response);
        }
    }
}