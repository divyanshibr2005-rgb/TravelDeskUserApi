using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using TravelDeskUserApi.Controllers;
using TravelDeskUserApi.IRepository;
using TravelDeskUserApi.Models;
using TravelDeskUserApi.Services;

namespace TravelDeskUserApi.Tests
{
    [TestFixture]
    public class AuthTests
    {
        private Mock<IUserRepository> _userRepoMock = null!;
        private AuthController _controller = null!;

        [SetUp]
        public void Setup()
        {
            _userRepoMock = new Mock<IUserRepository>();

            // Provide minimal in-memory configuration required by JwtService
            var inMemorySettings = new Dictionary<string, string?>
            {
                // Key must be at least 32 bytes for HS256 (use a sufficiently long test key)
                ["Jwt:Key"] = "TEST_KEY_012345678901234567890123456789012345",
                ["Jwt:Issuer"] = "TestIssuer",
                ["Jwt:Audience"] = "TestAudience",
                ["Jwt:ExpireMinutes"] = "60"
            };
            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(inMemorySettings)
                .Build();

            var jwtService = new JwtService(configuration);
            _controller = new AuthController(_userRepoMock.Object, jwtService);
        }

        [Test]
        public async Task Register_EmailAlreadyInUse_ReturnsConflict()
        {
            // Arrange
            var existing = new User { Uid = 1, Email = "used@x.com" };
            _userRepoMock.Setup(r => r.GetUserByEmail("used@x.com")).ReturnsAsync(existing);

            var request = new RegisterRequest
            {
                FirstName = "X",
                LastName = "Y",
                Email = "used@x.com",
                Password = "p",
                RoleId = 1
            };

            // Act
            var result = await _controller.Register(request);

            // Assert
            Assert.That(result, Is.InstanceOf<ConflictObjectResult>());
        }

        [Test]
        public async Task Login_InvalidCredentials_ReturnsUnauthorized()
        {
            // Arrange
            var stored = new User { Uid = 1, Email = "u@x.com", PasswordHash = "correct" };
            _userRepoMock.Setup(r => r.GetUserByEmail("u@x.com")).ReturnsAsync(stored);

            var request = new LoginRequest { Email = "u@x.com", Password = "wrong" };

            // Act
            var result = await _controller.Login(request);

            // Assert
            Assert.That(result, Is.InstanceOf<UnauthorizedObjectResult>());
        }

        [Test]
        public async Task Login_ValidCredentials_ReturnsOkWithToken()
        {
            // Arrange
            var stored = new User { Uid = 1, Email = "u@x.com", PasswordHash = "pwd" };
            _userRepoMock.Setup(r => r.GetUserByEmail("u@x.com")).ReturnsAsync(stored);

            var request = new LoginRequest { Email = "u@x.com", Password = "pwd" };

            // Act
            var result = await _controller.Login(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result;
            Assert.That(ok.Value, Is.InstanceOf<AuthResponse>());
            var resp = (AuthResponse)ok.Value!;
            Assert.That(resp.Token, Is.Not.Null);
        }
    }
}