using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using TravelDeskAPI.Controllers;
using TravelDeskUserApi.IRepository;
using TravelDeskUserApi.Models;

namespace TravelDeskUserApi.Tests
{
    [TestFixture]
    public class UsersControllerTests
    {
        private Mock<IUserRepository> _userRepoMock = null!;
        private UsersController _controller = null!;

        [SetUp]
        public void Setup()
        {
            _userRepoMock = new Mock<IUserRepository>();
            _controller = new UsersController(_userRepoMock.Object);
        }

        [Test]
        public async Task GetAllUsers_ReturnsOkWithUsers()
        {
            // Arrange
            var users = new List<User>
            {
                new User { Uid = 1, FirstName = "Alice", Email = "a@x.com" },
                new User { Uid = 2, FirstName = "Bob", Email = "b@x.com" }
            };
            _userRepoMock.Setup(r => r.GetAllUsers()).ReturnsAsync(users);

            // Act
            var result = await _controller.GetAllUsers();

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result.Result!;
            Assert.That(ok.Value, Is.EqualTo(users));
        }

        [Test]
        public async Task GetUser_Found_ReturnsOkWithUser()
        {
            // Arrange
            var user = new User { Uid = 10, FirstName = "X", Email = "x@x.com" };
            _userRepoMock.Setup(r => r.GetUserById(10)).ReturnsAsync(user);

            // Act
            var result = await _controller.GetUser(10);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result.Result!;
            Assert.That(ok.Value, Is.EqualTo(user));
        }

        [Test]
        public async Task CreateUser_DuplicateEmail_ReturnsConflict()
        {
            // Arrange
            var existingUser = new User { Uid = 1, Email = "duplicate@x.com" };
            _userRepoMock.Setup(r => r.GetUserByEmail("duplicate@x.com")).ReturnsAsync(existingUser);

            var newUser = new User { FirstName = "New", Email = "duplicate@x.com" };

            // Act
            var result = await _controller.CreateUser(newUser);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<ConflictObjectResult>());
        }

        [Test]
        public async Task CreateUser_ReturnsCreatedAtAction_WithAssignedId()
        {
            // Arrange
            var user = new User { FirstName = "New", Email = "new@x.com" };
            _userRepoMock.Setup(r => r.AddUser(It.IsAny<User>())).ReturnsAsync(42);

            // Act
            var result = await _controller.CreateUser(user);

            // Assert
            Assert.That(result.Result, Is.InstanceOf<CreatedAtActionResult>());
            var created = (CreatedAtActionResult)result.Result!;
            Assert.That(((User)created.Value!).Uid, Is.EqualTo(42));
        }

        [Test]
        public async Task UpdateUser_IdMismatch_ReturnsBadRequest()
        {
            // Arrange
            var user = new User { Uid = 2, FirstName = "Mismatch" };

            // Act
            var result = await _controller.UpdateUser(1, user);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
        }

        [Test]
        public async Task UpdateUser_NotFound_ReturnsNotFound()
        {
            // Arrange
            var user = new User { Uid = 5, FirstName = "NotFound" };
            _userRepoMock.Setup(r => r.UpdateUser(user)).ReturnsAsync(false);

            // Act
            var result = await _controller.UpdateUser(5, user);

            // Assert
            Assert.That(result, Is.InstanceOf<NotFoundResult>());
        }

        [Test]
        public async Task UpdateUser_Success_ReturnsNoContent()
        {
            // Arrange
            var user = new User { Uid = 7, FirstName = "OK" };
            _userRepoMock.Setup(r => r.UpdateUser(user)).ReturnsAsync(true);

            // Act
            var result = await _controller.UpdateUser(7, user);

            // Assert
            Assert.That(result, Is.InstanceOf<NoContentResult>());
        }

        [Test]
        public async Task DeleteUser_NotFound_ReturnsNotFound()
        {
            // Arrange
            _userRepoMock.Setup(r => r.DeleteUser(99)).ReturnsAsync(false);

            // Act
            var result = await _controller.DeleteUser(99);

            // Assert
            Assert.That(result, Is.InstanceOf<NotFoundResult>());
        }

        [Test]
        public async Task DeleteUser_Success_ReturnsOkWithMessage()
        {
            // Arrange
            _userRepoMock.Setup(r => r.DeleteUser(3)).ReturnsAsync(true);

            // Act
            var result = await _controller.DeleteUser(3);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var ok = (OkObjectResult)result;
            Assert.That(ok.Value, Is.Not.Null);
        }
    }
}